
    <h1 class="title">Pengolahan Data INACBG</h1>
    <div id="post">
       <b><br>Dikembangkan Oleh : <br>
		&nbsp;&nbsp;&nbsp;&nbsp;Khanza.Soft Media<br>
            Email : <br> 
			  &nbsp;&nbsp;&nbsp;&nbsp;Khanza.Media@yahoo.com,akhi_tangguh@yahoo.com<br>
            Skype : <br> 
			  &nbsp;&nbsp;&nbsp;&nbsp;khanza.media<br> 			 
			<br> Programmer : Windiarto Nugroho
			  </b>
		
    </div>
